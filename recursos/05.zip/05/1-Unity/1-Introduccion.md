# Introducción al desarrollo de videojuegos

El desarrollo de videojuegos en la actualidad es una de las industrias más grandes y con mayor crecimiento en el mundo. 

La mayoría de las grandes empresas de la industria utilizan sus propios motores de desarrollo, sin embargo, la mayoría son software propietario y no están al alcance de todos.

## ¿Qué es un motor de videojuegos?

Un motor de videojuegos es un software que proporciona un conjunto de herramientas y funciones para facilitar el desarrollo de videojuegos.

## ¿Se pueden hacer videojuegos sin un motor de videojuegos?

Sí, se pueden hacer videojuegos sin un motor de videojuegos, pero es mucho más complicado y requiere un conocimiento más profundo de programación y matemáticas.

## ¿Por qué usar un motor de videojuegos?

Los motores de videojuegos permiten a los desarrolladores centrarse en la creación de contenido y mecánicas de juego, sin tener que preocuparse por la programación de bajo nivel.  

## ¿Qué es Unity y por qué elegirlo para el desarrollo de videojuegos?

**Unity** es un motor de aplicaciones interactivas en **2D** o **3D**, comúnmente se conoce como un motor de videojuegos pero también pueden realizarse en él cualquier otro tipo de aplicación interactiva. 
El motor se encarga de las rutinas de programación para el diseño, creación y funcionamiento de un videojuego como puede ser el motor de renderizado, físicas, audio, animación y muchas más cosas. 

Sin embargo, otras opciones como **Unreal Engine** son más apropiadas si se viene de estudiar animación 3D ya que este es el motor más potente en este ámbito.

**Godot** por su parte, es un motor hasta el momento Open Source y totalmente gratuito, por lo tanto, tiene la ventaja de que en cuanto nos descargamos el motor, esta versión del mismo y mientras no cambie la idea de negocio, pasa a ser de nuestra propiedad y por lo tanto no está a la expectativa de ningún cambio por parte de la empresa desarrolladora, como sí ocurre con las otras dos opciones. 
El problema es que de momento Godot no tiene una comunidad tan grande, aunque sí es cierto que está en crecimiento continuo y podría llegar a ser una opción igual de viable

Existen una gran cantidad de otros motores, muchos incluso orientados a un tipo de juego en concreto como pueden ser:

- RPG Maker para juegos RPG en 2D.
- RenPY para novelas visuales o gráficas.
- LibGDX junto con GDX-liftoff para desarrollar juegos con Java y Gradle.
- GameMaker Studio para juegos 2D.
- Construct 3 para juegos 2D.
- Phaser para juegos 2D en navegador.
- Cocos2d para juegos 2D en dispositivos móviles.
- Unreal Engine para juegos 3D.
- Godot para juegos 2D y 3D.

Centrándonos pues, de nuevo en Unity, este nace en 2005 para generar proyectos en la plataforma mac pero debido a su éxito fue creciendo y evolucionando, incluyendo funcionalidades y plataformas hasta llegar a día de hoy con el cuál podemos exportar proyectos a sistemas operativos como windows, mac, linux, steam OS, android, en navegador con WebGL, Xbox, Playstation, Nintendo Switch, iOS, android tv, oculus etc. 
Aunque sí es cierto que para las consolas necesitaremos los DevKits para exportar a las mismas. 

Algunos juegos famosos desarrollados con Unity son Rust, Fall Guys, Gwent, Hearthstone, Arena of Valor, Cuphead, Super Mario Run, Pokémon Go, Resident Evil: Umbrella Corps, Assassin´s Creed Identity, etc. También son muchos los juegos desarrollados con Unity de realidad virtual, ya que es muy popular entre los desarrolladores de RV, algunos ejemplos son Rick y Morty. Virtual Rick-ality, Job Simulator o The Lab.

Para aprender a hacer videojuegos no es imprescindible aprender a Unity, tan solo es una opción entre muchas otras. 
Sin embargo es una de las mejores opciones debido a que es uno de los 3 motores de videojuegos más populares actualmente, los cuales son Unity, Unreal Engine y Godot. 
De los 3, Unity es el más popular y en general el más recomendable por el simple hecho de que al ser más popular, su comunidad de desarrolladores es mayor, y por lo tanto, la información, documentación y cantidad de foros activos que podemos encontrar hace que sea una opción más viable para empeza, ya que nos será más fácil encontrar ayuda para solucionar un problema en internet. 

Actualmente el lenguaje de scripting oficial de Unity es **C#**, lenguaje que nos será muy ameno para programar si venimos de Java, ya que comparten muchas cosas a nivel sintáctico y también es completamente orientado a objetos. 
Godot también proporciona soporte para este lenguaje pero no es su único lenguaje principal. 

